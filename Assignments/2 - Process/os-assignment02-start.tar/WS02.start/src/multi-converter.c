/**** multi-converter.c ****/

#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <converters.h>


#define _XOPEN_SOURCE 700



int main(int argc, char **argv)
{
    
    /**** TODO ****/
    
    printf("End of conversion\n");
    return EXIT_SUCCESS;
}
