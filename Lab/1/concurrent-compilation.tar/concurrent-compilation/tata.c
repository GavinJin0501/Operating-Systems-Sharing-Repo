#include "tata.h"

void tata() {
    printf("tata\n");
}