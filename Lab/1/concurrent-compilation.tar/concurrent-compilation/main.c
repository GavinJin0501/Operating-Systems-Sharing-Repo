#include "titi.h"
#include "tata.h"
#include "toto.h"

int main(int argc, char** argv) {
    titi();
    tata();
    toto();
}