#include "titi.h"

void titi() {
    printf("titi\n");
}