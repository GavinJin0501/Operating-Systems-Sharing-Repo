#include <stdio.h>

void toto();