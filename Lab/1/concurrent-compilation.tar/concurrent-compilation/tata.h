#include <stdio.h>

void tata();