#include <stdio.h>

void titi();