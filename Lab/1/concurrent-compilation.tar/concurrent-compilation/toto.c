#include "toto.h"

void toto() {
    printf("toto\n");
}